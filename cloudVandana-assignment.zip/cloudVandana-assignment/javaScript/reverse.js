function reverseWords(sentence) {
    let words = sentence.split(" ");

    let reversedWords = words.map(function(word){
        return word.split("").reverse().join("");
    })
    
    return reversedWords.join(" ");
}

let sentence = prompt("Enter a sentence:");

let result = reverseWords(sentence);

var demo = document.getElementById("demo");
demo.innerHTML = result;

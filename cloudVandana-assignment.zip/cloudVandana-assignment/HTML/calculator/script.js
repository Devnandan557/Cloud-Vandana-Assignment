let displayValue = '';

function appendToDisplay(value) {
    // Prevent multiple decimal points in a single number
    if (value === '.' && displayValue.includes('.')) return;

    displayValue += value;
    document.getElementById('display').value = displayValue;
}

function clearDisplay() {
    displayValue = '';
    document.getElementById('display').value = '';
}

function calculate() {
    // Validate if the input ends with an operator
    if (isValidExpression(displayValue)) {
        displayValue = eval(displayValue).toString();
        document.getElementById('display').value = displayValue;
    } else {
        document.getElementById('display').value = 'Error';
    }
}

function isValidExpression(expression) {
    // Ensure there are no trailing operators and it's not empty
    const operators = ['+', '-', '*', '/'];
    if (expression === '' || operators.includes(expression.slice(-1))) {
        return false;
    }

    // Check if expression contains only valid characters (numbers, operators, and decimal points)
    const validPattern = /^[0-9+\-*/.]+$/;
    return validPattern.test(expression);
}

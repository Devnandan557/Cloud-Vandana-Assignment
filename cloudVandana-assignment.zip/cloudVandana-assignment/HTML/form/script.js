document.getElementById("surveyForm").addEventListener("submit", function (e) {
    e.preventDefault(); 
    displayPopup();
});

function displayPopup() {

    const name = document.getElementById("name").value;
    
    const email = document.getElementById("email").value;
    const productValue = document.querySelector('input[name="productValue"]:checked').value;
    const suggest = document.querySelector('input[name="suggest"]:checked').value;
    const company = document.querySelector('input[name="company"]:checked').value;
    const suggestion = document.getElementById("suggestion").value;
    

    
    const formData = `
        <strong>First Name:</strong> ${name}<br>
        <strong>Email:</strong> ${email}<br>
        <strong>Is this first time you are using our product and services:</strong> ${productValue}<br>
        <strong>Would you suggest to your friends and collegaues:</strong> ${suggest}<br>
        <strong>How satisfied are you with our company overall:</strong> ${company}<br>
        <strong>Do you have suggestion to improve our service:</strong> ${suggestion}<br>
    `;
    document.getElementById("formData").innerHTML = formData;

    // Show the popup
    document.getElementById("popup").style.display = "flex";

    // close popup
    document.getElementById("closePopup").onclick = function () {
        document.getElementById("popup").style.display = "none";
        document.getElementById("surveyForm").reset(); // Reset form after closing the popup
    };
}

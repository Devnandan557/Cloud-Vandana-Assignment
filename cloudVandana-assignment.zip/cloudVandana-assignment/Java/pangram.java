import java.util.*;

public class PangramChecker {

    public static boolean isPangram(String sentence) {
        boolean[] alphabet = new boolean[26];
        int index;

        for (char c : sentence.toLowerCase().toCharArray()) {
            if (Character.isLetter(c)) {
                index = c - 'a'; 
                alphabet[index] = true; 
            }
        }

        for (boolean seen : alphabet) {
            if (!seen) {
                return false; 
            }
        }

        return true; 
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your sentence: ");
        String sentence = sc.nextLine();
        
        System.out.println(isPangram(sentence));
    }
}

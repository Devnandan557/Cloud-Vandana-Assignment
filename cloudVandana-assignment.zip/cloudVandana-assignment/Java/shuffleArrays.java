import java.util.Arrays;
import java.util.Random;

public class ShuffleArray {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7};

        shuffleArray(array);

        System.out.println(Arrays.toString(array));
    }

    // Fisher-Yates algorithm
    public static void shuffleArray(int[] array) {
        Random random = new Random();

        // Loop over the array from the last element to the second element
        for (int i = array.length - 1; i > 0; i--) {
        
            int j = random.nextInt(i + 1);  // Pick a random index from 0 to i

            // Swap array[i] with the element at random index array[j]
            int temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
    }
}
